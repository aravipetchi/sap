package com.opencart.testcases;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.opencart.utilities.ExcelReader;
import com.opencart.utilities.Helper;
import com.opencart.utilities.PDFHelper;

public class TestBase {
	WebDriver driver;
	String path = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
	final String URL = "https://demo.opencart.com";
	static int count = 1;
	File file;
	String expected, actual;

	public static int passed = 0, failed = 0;

	PDFHelper pdfHelper;

	@BeforeClass
	public void setUp() throws Exception {
		Document document = new Document();

		pdfHelper = new PDFHelper(document);
		pdfHelper.createPdf("Report101.pdf");

		pdfHelper.metaData();

		System.setProperty("webdriver.chrome.driver", path);
		driver = new ChromeDriver();
		driver.manage().window().maximize();

		file = Helper.takeSnapShot(driver, "Step_" + count);

		if (driver != null) {
			pdfHelper.addRow(count++, "Browser should open ", "Browser is opened", 1, file);
			++passed;
		} else {
			pdfHelper.addRow(count++, "Browser should open ", "Browser is not opened", 2, file);
			++failed;
		}

		driver.get(URL);

		file = Helper.takeSnapShot(driver, "Step_" + count);
		// pdfHelper.addRow(count++, "test2", "test1", 2, file);

		expected = "Your Store";
		actual = driver.getTitle();

		if (expected.equals(actual)) {
			pdfHelper.addRow(count++, "Title should be " + "\"" + expected + "\"", "Title is " + "\"" + actual + "\"",
					1, file);
			++passed;
		} else {
			pdfHelper.addRow(count++, "Title should be " + "\"" + expected + "\"", "Title is " + "\"" + actual + "\"",
					2, file);
			++failed;
		}
	}

	@AfterClass
	public void afterClass() throws DocumentException {
		
		pdfHelper.savePdf();
	}

	@DataProvider
	public Object[][] getData() throws IOException {
		String filepath = System.getProperty("user.dir") + "/src/com/opencart/testdata";
		String filename = "ProductList.xlsx";
		String sheetname = "Sheet1";
		return ExcelReader.ReadExcelDataObjecttoArr(filepath, filename, sheetname);
	}
}
