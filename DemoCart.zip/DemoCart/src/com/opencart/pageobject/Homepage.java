package com.opencart.pageobject;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.opencart.testcases.TestBase;
import com.opencart.utilities.Helper;
import com.opencart.utilities.PDFHelper;

public class Homepage extends TestBase{

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public void setSearchBtn(WebElement searchBtn) {
		this.searchBtn = searchBtn;
	}

	private WebDriver driver;

	@FindBy(linkText = "My Account")
	private WebElement accountDD;

	@FindBy(linkText = "Login")
	private WebElement login;

	@FindBy(linkText = "Logout")
	private WebElement logout;
	
	@FindBy(xpath="//*[@id=\"search\"]/span/button")
	private WebElement searchBtn;

	public Homepage(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getAcc() {
		return accountDD;
	}

	public void setAcc(WebElement acc) {
		this.accountDD = acc;
	}

	public WebElement getLog() {
		return login;
	}

	public void setLog(WebElement log) {
		this.login = log;
	}

	
	public void goToLogin(int count,PDFHelper pdfHelper) throws Exception {
		accountDD.click();

		Helper helper = new Helper(driver); 
		
			
		File file = Helper.takeSnapShot(driver,"Step_"+count);
		
		if (helper.isElementPresent(By.linkText("Login"))) {
			pdfHelper.addRow(count++, "Login link should be present", "Login link is present", 1, file);
			++passed;
		}
		else {
			pdfHelper.addRow(count++, "Login link should be present", "Login link is not present", 2, file);
			++failed;
		}
		login.click();
	}
	
	public void goToLogout(int count,PDFHelper pdfHelper) throws Exception {
		accountDD.click();
		Helper helper = new Helper(driver); 
		File file = Helper.takeSnapShot(driver,"Step_"+count);
		if (helper.isElementPresent(By.linkText("Logout"))) {
			pdfHelper.addRow(count++, "Logout link should be present", "Logout link is present", 1, file);
			++passed;
		}
		else {
			pdfHelper.addRow(count++, "Logout link should be present", "Logout link is not present", 2, file);
			++failed;
		}
		logout.click();
	}
	
}
