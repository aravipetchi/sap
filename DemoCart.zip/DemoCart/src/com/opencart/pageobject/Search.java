package com.opencart.pageobject;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.opencart.testcases.TestBase;
import com.opencart.utilities.Helper;
import com.opencart.utilities.PDFHelper;

public class Search extends TestBase{
	
WebDriver driver;
	
	@FindBy(xpath="//*[@id=\"input-search\"]")
	private WebElement searchTxt;
	
	@FindBy(name="category_id")
	private WebElement categoryDd;
	
	@FindBy(name ="sub_category")
	private WebElement subCategoryChk;
	
	@FindBy(name="description")
	private WebElement descriptionChk ;
	
	@FindBy(css="input[value='Search']")
	private WebElement searchBtn;
	
	
	//body/div[@id='product-search']/div[@class='row']/div[@id='content']/div[3]
	

	public Search(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getSearchTxt() {
		return searchTxt;
	}

	public void setSearchTxt(WebElement searchTxt) {
		this.searchTxt = searchTxt;
	}

	public WebElement getCategoryDd() {
		return categoryDd;
	}

	public void setCategoryDd(WebElement categoryDd) {
		this.categoryDd = categoryDd;
	}

	public WebElement getSubCategoryChk() {
		return subCategoryChk;
	}

	public void setSubCategoryChk(WebElement subCategoryChk) {
		this.subCategoryChk = subCategoryChk;
	}

	public WebElement getDescriptionChk() {
		return descriptionChk;
	}

	public void setDescriptionChk(WebElement descriptionChk) {
		this.descriptionChk = descriptionChk;
	}

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public void setSearchBtn(WebElement searchBtn) {
		this.searchBtn = searchBtn;
	}

	
	public void performSearch(String productName, String searchCat,int count,PDFHelper pdfHelper) throws Exception {
		
		searchTxt.clear();
		searchTxt.sendKeys(productName);
		Select sel = new Select(categoryDd);
		sel.selectByVisibleText(searchCat);
		subCategoryChk.click();
		descriptionChk.click();
		
		File file = Helper.takeSnapShot(driver,"Step_"+count);
		pdfHelper.addRow(count,"Product details should be filled", "Product details is filled", 1,file);
		++passed;
		searchBtn.click();
	}
}
