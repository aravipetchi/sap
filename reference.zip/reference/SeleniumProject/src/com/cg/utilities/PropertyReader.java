package com.cg.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {
	public static Properties prop = null;
	public static FileInputStream inputstream = null;

	public static String getProperty(String PropertyName) throws IOException {
		String PropertyValue = "";
		inputstream = new FileInputStream(new File(System.getProperty("user.dir") + "/src/com/cg/config/config.properties"));
		prop = new Properties();
		prop.load(inputstream);
		PropertyValue = prop.getProperty(PropertyName);

		return PropertyValue;
	}

	public static void main(String args[]) throws IOException {
		System.out.println(PropertyReader.getProperty("appurl"));
	}
}
