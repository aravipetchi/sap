package com.cg.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Hashtable;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	
	public static Object[][] ReadExcelDataToObjectArr(String filepath,String filename,String sheetname) throws IOException
	{
		File file = new File(filepath+"/"+filename);
		FileInputStream inputstream = new FileInputStream(file);
		XSSFWorkbook workbook = new XSSFWorkbook(inputstream);
	    Sheet sheet = workbook.getSheet(sheetname);
		
		int rowcount = sheet.getLastRowNum();
		Object[][]data = new Object[rowcount][1];
		Row KeyRow = sheet.getRow(0);
		Hashtable<String,String> rec = null;
		for(int r = 1;r<rowcount+1;r++) {
			Row datarow = sheet.getRow(r);
			rec = new Hashtable<String,String>();
			for(int c = 0;c<datarow.getLastCellNum();c++) {
				String key = KeyRow.getCell(c).getStringCellValue();
				String val = datarow.getCell(c).getStringCellValue();
				rec.put(key, val);
			}
			data[r-1][0] = rec;
		}
		return data;
		
		
		
	}
	
	public static void ReadExcelData(String filepath,String filename,String sheetname) throws IOException
	{
		File file = new File(filepath+"/"+filename);
		FileInputStream inputstream = new FileInputStream(file);
		XSSFWorkbook workbook = new XSSFWorkbook(inputstream);
	    Sheet sheet = workbook.getSheet(sheetname);
		
		int rowcount = sheet.getLastRowNum();
		for(int r = 0;r<rowcount+1;r++) {
			Row row = sheet.getRow(r);
			for(int c = 0;c<row.getLastCellNum();c++) {
				Cell cell = row.getCell(c);
				System.out.print(cell.getStringCellValue()+"\t");
			}
			System.out.println("");
		}
		
		
		
	}

	public static void main(String[] args) throws IOException {
		String filename="CalorieData.xlsx";
        String filepath= System.getProperty("user.dir") +"/src/com/cg/testdata";
        String sheetname = "CalorieTestSet";
        ExcelReader.ReadExcelData(filepath, filename, sheetname);
        //ExcelReader.ReadExcelDataToObjectArr(filepath, filename, sheetname);
	}

}
