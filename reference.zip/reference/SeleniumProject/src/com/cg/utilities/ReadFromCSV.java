package com.cg.utilities;

import java.util.List;

import org.testng.annotations.Test;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import au.com.bytecode.opencsv.CSVReader;

public class ReadFromCSV {
	@Test
	public void ReadCSV() throws IOException {
		String filename = System.getProperty("user.dir") + "/src/com/cg/testdata/CalorieCSVData.csv";
		FileReader reader = new FileReader(new File(filename));
		@SuppressWarnings("resource")
		CSVReader csvreader = new CSVReader(reader);
		List<String[]> lst = csvreader.readAll();
		Iterator<String[]> itr = lst.iterator();
		while (itr.hasNext()) {
			String[] s = itr.next();
			for (int i = 0; i < s.length; i++) {
				System.out.print(s[i] + "\t");
			}
			System.out.println(" ");
		}

	}

}
