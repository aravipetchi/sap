package com.cg.grid;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
//import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class CalorieCalcGridTestCase {
	WebDriver driver;
	DesiredCapabilities cap = null;
	//String browser = "chrome";
	@Parameters({"browser"})
	@Test
	public void CalorieDetails(String browser) throws MalformedURLException, InterruptedException {
		if(browser.equals("chrome")) {
			cap = DesiredCapabilities.chrome();
			//cap.setBrowserName(browser);
			//cap.setPlatform(Platform.ANY);
	        //cap.setVersion("");
		}
		else if(browser.equals("firefox")) {
			cap = DesiredCapabilities.firefox();
		}
		else if(browser.equals("InternetExplorer")) {
			cap = DesiredCapabilities.internetExplorer();
		}
		driver = new RemoteWebDriver(new URL("http://localhost:4446/wd/hub"),cap);
		driver.get("https://www.calculator.net//calorie-calculator.html");
		WebElement ageTextbox = driver.findElement(By.id("cage"));
		ageTextbox.clear();
		ageTextbox.sendKeys("45");
		Thread.sleep(1000);
		driver.close();
	}
	

}
