package com.cg.testcases;

import java.io.IOException;
//import java.util.Hashtable;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

//import com.cg.pageobjects.CaloriePage;
import com.cg.utilities.PropertyReader;



public class CalorieTestCase {
	WebDriver driver;

	@Test(dataProvider = "getCalorieData")
	public void EnterCalorieDetails(String age, String sexname, String weight) throws InterruptedException, IOException {
	//public void EnterCalorieDetails(Hashtable<String,String>caldata) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");

		WebElement ageTextbox = driver.findElement(By.id(PropertyReader.getProperty("cp_ageid")));
		ageTextbox.clear();
		ageTextbox.sendKeys(age);
		Thread.sleep(1000);

		List<WebElement> genderList = driver.findElements(By.name(PropertyReader.getProperty("cp_sexname")));
		for (WebElement gender : genderList) {
			if (gender.getAttribute("value").equals(sexname)){
				if (!gender.isSelected()) {
					gender.click();
					break;
				}
			}
		}
		WebElement weightTextbox = driver.findElement(By.xpath(PropertyReader.getProperty("cp_weight_xpath")));
		weightTextbox.clear();
		weightTextbox.sendKeys(weight);
		
		
		/*CaloriePage cp= new CaloriePage(driver);
		cp.EnterCalorie(caldata.get("age"),caldata.get("sexname"),caldata.get("weight"));*/
	}

	@DataProvider
	public Object[][] getCalorieData() {
		String[][] caldata = new String[2][3];
		caldata[0][0] = "45";
		caldata[0][1] = "f";
		caldata[0][2] = "200";
		caldata[1][0] = "56";
		caldata[1][1] = "m";
		caldata[1][2] = "180";
		
		/*Object[][]caldata = new Object[2][1];
		Hashtable<String,String> rec1 = new Hashtable<String,String>();
		rec1.put("age", "50");
		rec1.put("sexname", "f");
		rec1.put("weight", "100");
		Hashtable<String,String> rec2 = new Hashtable<String,String>();
		rec2.put("age", "40");
		rec2.put("sexname", "m");
		rec2.put("weight", "120");
		caldata[0][0] = rec1;
		caldata[1][0] = rec2;*/
		return caldata;
		
      
	}
}
