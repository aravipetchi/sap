package com.cg.testcases;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class HandleAlerts {
	WebDriver driver;
	@Test
	public void Handlepopus() throws InterruptedException  {
    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("https://www.calculator.net//calorie-calculator.html");
	
	JavascriptExecutor js = (JavascriptExecutor)driver;
	js.executeScript("alert('This is an information message');");
	Alert alert = driver.switchTo().alert();
	String alertMsg = alert.getText();
	//Thread.sleep(2000);
	alert.accept();
	if(alertMsg.equals("This is an information message"))
	{
		System.out.println("Alert message match found");
	}
	else
	{
		System.out.println("Alert message match not found");
    }
	driver.close();
	}
	
}
