package com.cg.testcases;

import java.util.Iterator;
import java.util.Set;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class WindowNavigation {
	WebDriver driver;
	@Test
	public void WindowNavTest() throws InterruptedException {
    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("https://www.online.citibank.co.in/products-services/online-services/internet-banking.htm");
	driver.manage().window().maximize();
	String ParentWindowID = driver.getWindowHandle();
	System.out.println("parent window id"+ ParentWindowID);
	driver.findElement(By.xpath("//*[@id=\'main\']/div[1]/div[2]/a")).click();
	Set<String> winids = driver.getWindowHandles();
	Iterator<String>itr = winids.iterator();
	String mainwinid = itr.next().toString();
	String subwinid = itr.next().toString();
	System.out.println("Main window Id"+ mainwinid);
	System.out.println("sub window Id"+ subwinid);
	driver.switchTo().window(subwinid);
	driver.findElement(By.name("User_Id")).sendKeys("Selenium");
	Thread.sleep(2000);
	driver.close();
	driver.switchTo().window(mainwinid);
	driver.findElement(By.id("topMnuinsurance")).click();
	Thread.sleep(2000);
	driver.close();
	}

}
