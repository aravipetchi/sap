package com.cg.testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


public class ReadFromXml 
    {
    WebDriver driver;
    public FileInputStream inputStream = null;
	@Test
	public void EnterCalorieDetailsFromXml() throws FileNotFoundException, DocumentException 
		{
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://www.calculator.net/calorie-calculator.html");
			
			String filename = System.getProperty("user.dir")+"/src/com/cg/testdata/CalorieXml.xml";
			inputStream = new FileInputStream(new File(filename));
			
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputStream);
			String age = document.selectSingleNode("//CalorieDetails/age").getText();
			
			WebElement ageTextbox = driver.findElement(By.id("cage"));
			ageTextbox.clear();
			ageTextbox.sendKeys(age);
			
			
			
			
		}
	}
