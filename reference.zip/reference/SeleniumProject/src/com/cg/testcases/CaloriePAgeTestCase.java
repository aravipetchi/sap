package com.cg.testcases;

//import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.cg.pageobjects.CaloriePage;

public class CaloriePAgeTestCase {
	
		WebDriver driver;
		@Test
		public void EnterCalorieDetails() throws InterruptedException {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		    driver = new ChromeDriver();
			driver.get("https://www.calculator.net//calorie-calculator.html");
			CaloriePage cp = new CaloriePage(driver);
			cp = PageFactory.initElements(driver,CaloriePage.class);
			cp.setAge("35");
			Thread.sleep(2000);
			System.out.println(cp.getAge());
			cp.EnterCalorie("45","f","200");
			Thread.sleep(2000);
			driver.close();
		}
		
		
	
	

}
