package com.cg.pageobjects;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CaloriePage {
	
	@FindBy(id="cage")
	private WebElement ageTextbox;
	
	@FindBy(name="csex")
	private List <WebElement> genderList;
	
	@FindBy(xpath="//*[@id='cpound']")
	private WebElement WeightTextbox;
	
	@FindBy(how = How.LINK_TEXT,using = "BMI")
	private WebElement BMILink;
	
	WebDriver driver;
	public CaloriePage(WebDriver driver)
	{
	this.driver = driver;
	//for initializing page elements we need to use PageFacory
    PageFactory.initElements(driver, this);
	}
	
	public void EnterCalorie(String age,String sex,String weight)
	{
		ageTextbox.clear();
		ageTextbox.sendKeys(age);
		for (WebElement gender : genderList) {
			if (gender.getAttribute("value").equals(sex)) {
				if (!gender.isSelected()) {
					gender.click();
					break;
				}
			}
		}
		WeightTextbox.clear();
		WeightTextbox.sendKeys(weight);
	}
	public void ClickBMILink() {
		BMILink.click();
	}

	public void setAge(String age) {
		ageTextbox.clear();
		ageTextbox.sendKeys(age);
		
		
	}
	
public String getAge() {
	return ageTextbox.getAttribute("value");
	
}
	

}
