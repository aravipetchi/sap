package Launch;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;

import java.util.*;
public class Dummy {
	  private WebDriver driver;
	  JavascriptExecutor js;
	  @BeforeMethod
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
	    driver = new ChromeDriver();
	    js = (JavascriptExecutor) driver;
	    new HashMap<String, Object>();
	  }
	  @AfterMethod
	public void tearDown() {
	    driver.quit();
	  }
	  @Test
	  public void testing() {
	    driver.get("https://www.calculator.net/calorie-calculator.html");
	    driver.manage().window().setSize(new Dimension(1296, 1000));
	    driver.findElement(By.cssSelector(".panel2")).click();
	    driver.findElement(By.id("cage")).clear();
	    driver.findElement(By.id("cage")).sendKeys("18");
	    driver.findElement(By.cssSelector("td > .cbcontainer:nth-child(2) > .rbmark")).click();
	    driver.findElement(By.cssSelector("#standardheightweight > tbody > tr:nth-child(1)")).click();
	    driver.findElement(By.id("cheightfeet")).sendKeys("6");
	    driver.findElement(By.cssSelector("#standardheightweight tr:nth-child(2)")).click();
	    driver.findElement(By.id("cpound")).sendKeys("170");
	    driver.findElement(By.id("cactivity")).click();
	    {
	      WebElement dropdown = driver.findElement(By.id("cactivity"));
	      dropdown.findElement(By.xpath("//option[. = 'Light: exercise 1-3 times/week']")).click();
	    }
	    driver.findElement(By.id("cactivity")).click();
	    driver.findElement(By.cssSelector("td:nth-child(2) > input:nth-child(2)")).click();
	  }
	}
