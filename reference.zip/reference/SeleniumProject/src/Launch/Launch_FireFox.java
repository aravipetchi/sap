package Launch;

import org.openqa.selenium.firefox.FirefoxDriver;

public class Launch_FireFox {

	public static void main(String[] args) 
	{
		//System.setProperty("webdriver.ie.driver","D:\\Users\\srramesh\\Desktop\\Advanced Selenium Libs\\WebDriver API\\IEDriverServer.exe");
		System.setProperty("webdirver.gecko.driver","./Driver/geckodriver.exe");
		
		FirefoxDriver fdriver = new FirefoxDriver();
		
		fdriver.get("https://www.google.com");
	}

}
