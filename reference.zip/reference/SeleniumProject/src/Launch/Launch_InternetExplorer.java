package Launch;

import org.openqa.selenium.ie.InternetExplorerDriver;

public class Launch_InternetExplorer {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.ie.driver", "./Driver/IEDriverServer.exe");
		InternetExplorerDriver driver = new InternetExplorerDriver();
		
		driver.get("https://www.google.com");
	}
}
