package Launch;

import org.openqa.selenium.chrome.ChromeDriver;

public class Launch_Chrome {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Driver/chromedriver.exe");
	
		ChromeDriver driver = new ChromeDriver();
	
		driver.get("https://www.google.com");
		
		Thread.sleep(1000);
		driver.close();
	}

}
