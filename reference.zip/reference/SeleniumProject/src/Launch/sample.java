package Launch;

import org.junit.Test;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class sample {
@Test
	public void Headlesshtml() throws InterruptedException {
	HtmlUnitDriver driver = new HtmlUnitDriver();
	driver.get("https://www.calculator.net/calorie-calculator.html");
	Thread.sleep(1000);
	System.out.println("Title is "+driver.getTitle());
	}


}
