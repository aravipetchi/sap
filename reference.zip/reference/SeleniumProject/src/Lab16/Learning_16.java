package Lab16;


import static org.testng.Assert.assertEquals;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Learning_16 {
	
	WebDriver driver;
	@BeforeClass
	public void before() {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://demo.opencart.com/index.php?route=account/register");
		
	}
	
	@Parameters({"firstname1","lastname","email","telephone","pass","conformpass"})
	@Test	
	public void StoreDetails(String firstname1, String lastname, String email, String telephone, String pass, String conformpass) throws InterruptedException{
		
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();
		WebElement firstTxt=driver.findElement(By.xpath("//*[@id=\"input-firstname\"]"));
		firstTxt.clear();
		firstTxt.sendKeys(firstname1);
		WebElement lastTxtdriver= driver.findElement(By.name("lastname"));
		lastTxtdriver.clear();
		lastTxtdriver.sendKeys(lastname);
		WebElement emailTxt = driver.findElement(By.id("input-email"));
		emailTxt.clear();		
		emailTxt.sendKeys(email);
		WebElement telTxt = driver.findElement(By.id("input-telephone"));
		telTxt.clear();		
		telTxt.sendKeys(telephone);
		WebElement passwrd = driver.findElement(By.id("input-password"));
		passwrd.clear();
		passwrd.sendKeys(pass);
		WebElement confirmpass = driver.findElement(By.id("input-confirm"));
		confirmpass.clear();
		confirmpass.sendKeys(conformpass);
		WebElement chkbox = driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[1]"));
		chkbox.click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[2]")).click();
		
		
		String expected = "Your Account Has Been Created!" ;
		String actual = driver.findElement(By.xpath("//*[@id=\"content\"]/h1")).getText();
		assertEquals(actual, expected);
		System.out.println("Account Created Title is Valid");
		
		Thread.sleep(2000);
		driver.findElement(By.linkText("Logout")).click();
		
	}
	
}

