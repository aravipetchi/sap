package assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Learning_03 {
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Driver/chromedriver.exe");
	
		ChromeDriver driver = new ChromeDriver();
	
		driver.get("https://demo.opencart.com/index.php?route=common/home");
		
		driver.findElement(By.partialLinkText("Desktop")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.partialLinkText("Mac")).click();
		Thread.sleep(2000);
		

		WebElement dd= driver.findElement(By.id("input-sort"));
		Select sel = new Select(dd);
		sel.selectByIndex(1);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();
		Thread.sleep(2000);
		
		driver.close();
	}

}
