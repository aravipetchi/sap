package assignment;



import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Learning_10b {
	WebDriver driver;
	DesiredCapabilities cap = null;
	
	@Parameters({"browser"})
	@Test
	public void Lab04(String browser) throws MalformedURLException, InterruptedException {
		if(browser.equals("chrome")) {
			cap = DesiredCapabilities.chrome();
		}
		else if(browser.equals("firefox")) {
			cap = DesiredCapabilities.firefox();
		}
		else if(browser.equals("InternetExplorer")) {
			cap = DesiredCapabilities.internetExplorer();
		}
		driver = new RemoteWebDriver(new URL("http://localhost:4446/wd/hub"),cap);
		
        driver.get("https://demo.opencart.com/index.php?route=common/home");
		
        driver.findElement(By.partialLinkText("Desktop")).click();
		Thread.sleep(2000);

		driver.findElement(By.partialLinkText("Mac")).click();
		Thread.sleep(2000);
		
		String Title = driver.getTitle();
		System.out.println("The Title is : " + Title);

		if (Title.equals("Mac")) {
			System.out.println("Passed");
		} else {
			System.out.println("Fail");
		}

		WebElement dd= driver.findElement(By.id("input-sort"));
		Select sel = new Select(dd);
		sel.selectByIndex(1);
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\'search\']/input")).click();
		driver.findElement(By.xpath("//*[@id=\'search\']/input")).sendKeys("Mobile");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\'search\']/span/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"input-search\"]")).clear();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"content\"]/p[1]/label")).click();
		driver.findElement(By.id("button-search")).click();

		Thread.sleep(1000);
		driver.close();
	}
	


}
