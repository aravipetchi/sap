package assignment;



import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Learning_06 {
	
public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://demo.opencart.com/");
		Thread.sleep(1000);
		
		//my account
		WebElement drp=driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/span[2]"));
		drp.click();
		Thread.sleep(1000);
		
		//login
		WebElement log=driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a"));
		log.click();
		Thread.sleep(1000);
		
		//mail
		WebElement mail=driver.findElement(By.id("input-email"));
		mail.sendKeys("johncena98@gmail.com");
		Thread.sleep(1000);
		
		//password
		WebElement pass=driver.findElement(By.id("input-password"));
		pass.sendKeys("Hello@98");
		Thread.sleep(1000);
		
		
		WebElement btn=driver.findElement(By.cssSelector("#content > div > div:nth-child(2) > div > form > input"));
		btn.click();
		Thread.sleep(1000);
		
		WebElement components=driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[3]/a"));
		components.click();
		Thread.sleep(1000);
		
		WebElement comp=driver.findElement(By.cssSelector("#menu > div.collapse.navbar-collapse.navbar-ex1-collapse > ul > li:nth-child(3) > div > div > ul > li:nth-child(2) > a"));
		comp.click();
		Thread.sleep(1000);
		
		WebElement list=driver.findElement(By.id("input-limit"));
		Select sel = new Select(list);
		sel.selectByIndex(1);
		Thread.sleep(1000);
		
		//add to cart
		WebElement cart = driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div[1]/div/div[2]/div[2]/button[1]"));
		cart.click();
		Thread.sleep(1000);
		
		//specification
		WebDriverWait wait = new WebDriverWait(driver,30);
		try
		{
		wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText("Specification")));	
		WebElement spec = driver.findElement(By.partialLinkText("Specification"));
		spec.click();
		Thread.sleep(2000);
		}
		catch(NoSuchElementException e){
			
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[2]/div[1]/button[1]")).click();
		Thread.sleep(2000);
		
		//verify wishlist message
		String expected = "Success: You have added Apple Cinema 30 to your wish list!";
		String actual = driver.findElement(By.xpath("//*[@id=\"product-product\"]/div[1]")).getText();

		if (expected.equalsIgnoreCase(actual)) {
			System.out.println("wishlist message Test Passed");
		} else {
			System.out.println("wishlist message Test Failed");
		}
		
		//search field
		driver.findElement(By.name("search")).sendKeys("mobile");
		Thread.sleep(1000);
		
		//search button
		driver.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.name("description")).click();
		Thread.sleep(1000);
		
		//search button
		driver.findElement(By.id("button-search")).click();
		Thread.sleep(1000);
		
		//htc mobile link
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div[1]/div/div[2]/div[1]/h4/a")).click();
		Thread.sleep(1000);
		
		//quqntity
		WebElement qty = driver.findElement(By.name("quantity"));
		qty.clear();
		qty.sendKeys("3");
		Thread.sleep(1000);
		
		//add to cart
		driver.findElement(By.id("button-cart")).click();
		Thread.sleep(1000);
		
		//verify htc wishlist
		String expected1 = " Success: You have added ";
		String actual1 = driver.findElement(By.xpath("//*[@id=\"product-product\"]/div[1]")).getText();
		if (expected1.equalsIgnoreCase(actual1))
		{
			System.out.println("HTC wishlist message Test Passed");
		} else {
			System.out.println("HTC wishlist message Test Failed");
		}
		
		driver.findElement(By.xpath("//*[@id=\"cart\"]/button")).click();
		Thread.sleep(1000);
		
		//verify mobile name
		String expected2 = "HTC Touch HD";
		String actual2 = driver.findElement(By.xpath("//*[@id=\"cart\"]/ul/li[1]/table/tbody/tr/td[2]/a")).getText();

		if (expected2.equalsIgnoreCase(actual2)) {
			System.out.println("Mobile name Test Passed");
		} else {
			System.out.println("Mobile name  Test Failed");
		}
		
		//checkout
		driver.findElement(By.xpath("//*[@id=\"cart\"]/ul/li[2]/div/p/a[2]/strong")).click();
		Thread.sleep(1000);
		
		//my accont
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
		Thread.sleep(1000);
		
		//logout
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[5]/a")).click();
		Thread.sleep(1000);
		
		//logout heading verify
		String expected3 = "Account Logout";
		String actual3 = driver.findElement(By.xpath("//*[@id=\"content\"]/h1")).getText();

		if (expected3.equalsIgnoreCase(actual3)) {
			System.out.println("Logout heading Test Passed");
		} else {
			System.out.println("Logout heading Test Failed");
		}
		
		//continue
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/a")).click();
		Thread.sleep(1000);
		
		driver.close();
     }
			
}
		
		


