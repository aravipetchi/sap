package assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Learning_05 {

	public static void main(String[] args) throws NoSuchElementException, InterruptedException {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://demo.opencart.com/index.php?route=common/home");

		String expectedTitle = "Your Store";
		String actualTitle = driver.getTitle();
		System.out.println("The Title is :" + actualTitle);

		if (expectedTitle.equals(actualTitle)) {
			System.out.println("Test Passed");
		} else {
			System.out.println("Test Failed");
		}

		// my account
		WebElement myaccdrpdown = driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/span[2]"));
		myaccdrpdown.click();
		Thread.sleep(2000);

		// register
		WebElement myaccregister = driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[1]/a"));
		myaccregister.click();
		Thread.sleep(2000);

		// title validation
		String expectedTitle1 = "Register Account";
		String actualTitle1 = driver.getTitle();
		System.out.println("The Title is :" + actualTitle1);

		if (expectedTitle1.equals(actualTitle1)) {
			System.out.println("Title test : Test Passed");
		} else {
			System.out.println("Title test : Test Failed");
		}

		// continue
		driver.findElement(By.cssSelector("#content > form > div > div > input.btn.btn-primary")).click();
		Thread.sleep(2000);

		String errmessage = driver
				.findElement(By.cssSelector("#account-register > div.alert.alert-danger.alert-dismissible")).getText();
		String expectedMessage = "Warning: You must agree to the Privacy Policy!";

		if (expectedMessage.equals(errmessage)) {
			System.out.println("Error Message Test Passed");
		} else {
			System.out.println("Error Message Test Failed");
		}

		driver.findElementByName("firstname").sendKeys("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");

		// continue
		//driver.findElementByXPath("//*[@id=\"top-links\"]/ul/li[2]/a/span[2]").click();

		String username = driver.findElement(By.xpath("//*[@id=\'account\']/div[2]/div/div")).getText();
		String expectedusrname = "First Name must be between 1 and 32 characters!";

		if (expectedusrname.equals(username)) {
			System.out.println("Username Error Message Passed");
		} else {
			System.out.println("Username Error Message Failed");
		}

		// correct First
		WebElement first = driver.findElementByName("firstname");
		first.clear();
		first.sendKeys("Mahes");

		// continue
		//driver.findElementByXPath("//*[@id=\"top-links\"]/ul/li[2]/a/span[2]").click();

		driver.findElementByName("lastname").sendKeys("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");

		driver.findElementByXPath("//*[@id=\"content\"]/form/div/div/input[2]").click();

		String lastname = driver.findElement(By.xpath("//*[@id=\"account\"]/div[3]/div/div")).getText();
		String expectedlstname = "Last Name must be between 1 and 32 characters!";

		if (expectedlstname.equalsIgnoreCase(lastname)) {
			System.out.println("Lastname Error Message Passed");
		} else {
			System.out.println("Lastname Error Message Failed");
		}

		// correct Last
		WebElement Last = driver.findElementByName("lastname");
		Last.clear();
		Last.sendKeys("waran");

		// continue
		driver.findElementByXPath("//*[@id=\'content\']/form/div/div/input[2]").click();

		driver.findElement(By.id("input-email")).sendKeys("mahes182@gmail.com");
		Thread.sleep(1000);

		driver.findElement(By.id("input-telephone")).sendKeys("9876543210");
		Thread.sleep(1000);

		driver.findElement(By.id("input-password")).sendKeys("cap123");
		Thread.sleep(1000);

		driver.findElement(By.id("input-confirm")).sendKeys("cap123");
		Thread.sleep(1000);

		driver.findElement(By.xpath("//*[@id=\'content\']/form/fieldset[3]/div/div/label[1]/input")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[1]")).click();

		// continue
		driver.findElementByXPath("//*[@id=\'content\']/form/div/div/input[2]").click();
		Thread.sleep(2000);

		// verify message "Your Account Has Been Created!"
		String actualMsg = driver.findElementByXPath("//*[@id=\"content\"]/h1").getText();
		String expectedmsg = "Your Account Has Been Created!";

		if (actualMsg.equals(expectedmsg)) {
			System.out.println("Verified message-Account registered");
		} else {
			System.out.println("Message verification failed");
		}

		// continue
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/a")).click();

		// my orders
		driver.findElement(By.xpath("//*[@id=\"content\"]/ul[2]/li[1]/a")).click();

		// continue
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/a")).click();

		Thread.sleep(2000);

		// ADDRESS BOOK
		driver.findElementByLinkText("Address Book").click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/a")).click();
		Thread.sleep(1000);

		// address1
		driver.findElementById("input-address-1").sendKeys("Aravindan");

		// city
		driver.findElementById("input-city").sendKeys("chennai");

		// pincode
		WebElement pincode = driver.findElementById("input-postcode");
		pincode.sendKeys("641034");
		Thread.sleep(2000);

		// country
		WebElement count = driver.findElement(By.id("input-country"));
		Thread.sleep(2000);

		// count.sendKeys("India");
		Select con = new Select(count);
		con.selectByValue("99");
		Thread.sleep(2000);

		// region<select name="country_id" id="input-country" class="form-control">

		WebElement zone = driver.findElement(By.xpath("//*[@id=\"input-zone\"]"));
		Select opt = new Select(zone);
		opt.selectByValue("1503");
		Thread.sleep(2000);
		
		driver.close();

	}

}
