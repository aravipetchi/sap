package Lab12;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Testcasepropertyfile12 {

	@Test
	public void fun() throws InterruptedException, IOException {

		new Testcasepropertyfile12().TestCase("Mobile", "Monitors");

	}

	public void TestCase(String firstsearch, String secondSearch) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		String actualTitle = driver.getTitle();
		System.out.println("the title is " + actualTitle);

		String Title = "Your Store";
		if (actualTitle.equals(Title)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
		// selecting Desktop button

		driver.findElement(By.xpath(propertyReader_12.getProperty("desktop_button"))).click();
		// clicking Mac (1)

		driver.findElement(By.xpath(propertyReader_12.getProperty("click_Mac"))).click();
		// verifying Mac heading with xpath

		String headTitle = driver.findElement(By.xpath(propertyReader_12.getProperty("verify_MacHead"))).getText();
		String heading = "Mac";
		if (headTitle.equals(heading)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
		// dropdown

		WebElement dd = driver.findElement(By.id(propertyReader_12.getProperty("dropdown_search")));
		Select sel = new Select(dd);
		// select one in dropdown

		sel.selectByVisibleText(propertyReader_12.getProperty("Select_dropdown"));
		// add to cart

		driver.findElement(By.xpath(propertyReader_12.getProperty("add_to_cart"))).click();

		// selecting search field and send to keys

		WebElement search = driver.findElement(By.name(propertyReader_12.getProperty("sel_Sear_SendKeys")));

		search.sendKeys(firstsearch);
		// searching

		driver.findElement(By.className(propertyReader_12.getProperty("searching"))).click();
		Thread.sleep(3000);
		// find search and clear searching items

		WebElement searchc = driver.findElement(By.xpath(propertyReader_12.getProperty("search_clear")));
		searchc.clear();
		// description selection

		driver.findElement(By.name(propertyReader_12.getProperty("select_descrip"))).click();
		// search the items

		driver.findElement(By.id(propertyReader_12.getProperty("click_search"))).click();
		// click search clear and send keys

		WebElement searchn = driver.findElement(By.id(propertyReader_12.getProperty("Sear_clear")));
		searchn.clear();

		searchn.sendKeys(secondSearch);
		// click search

		driver.findElement(By.id(propertyReader_12.getProperty("searche"))).click();
	}

}
