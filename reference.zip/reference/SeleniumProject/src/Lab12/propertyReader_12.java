package Lab12;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class propertyReader_12 {
	public static Properties prop = null;
	public static FileInputStream inputStream = null;

	public static String getProperty(String PropertyName) throws IOException {
		String PropertyValue = "";
		inputStream = new FileInputStream(new File(System.getProperty("user.dir")) + "/src/Lab12/config12.property");
		prop = new Properties();
		prop.load(inputStream);
		PropertyValue = prop.getProperty(PropertyName);
		return PropertyValue;
	}

	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println(propertyReader_12.getProperty("url"));
		Testcasepropertyfile12 tc = new Testcasepropertyfile12();
		tc.fun();

	}

}
