package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByCSS {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
	
		String Title = driver.getTitle();
		System.out.println("The Title is : " + Title);

		if (Title.equals("Calorie Calculator")) {
			System.out.println("Passed");
		} else {
			System.out.println("Fail");
		}

		//System.out.println(driver.getCurrentUrl()); 
		//System.out.println(" ");
		//System.out.println(driver.getPageSource());

		driver.findElement(By.cssSelector("input[name='cage']")).clear();
		driver.findElement(By.cssSelector("input[name='cage']")).sendKeys("12");
		driver.findElement(By.cssSelector("input#cheightfeet")).clear();
		driver.findElement(By.cssSelector("input#cheightfeet")).sendKeys("12");
		
		String str = driver.findElement(By.id("cage")).getAttribute("value");
		System.out.println(str);
		
		
		Thread.sleep(1500);
		driver.close();
	}

}
