package Locators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class sample {
	public static void main(String args[]) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
		// Thread.sleep(1000);

		WebElement ageTextbox = driver.findElement(By.id("cage"));
		// ageTextbox.clear();
		ageTextbox.sendKeys(Keys.chord(Keys.CONTROL, "a"));

		WebElement ageLabel = driver.findElement(By.xpath("//*[@id=\"standardheightweight\"]/tbody/tr[1]/td[2]"));
		System.out.println(ageLabel.getText());
		Select Country = new Select(driver.findElement(By.id("cactivity")));
		List<WebElement> elementCount = Country.getOptions();
		System.out.println(elementCount.size());
		for (int i = 0; i < 10; i++) {
			String sValue = elementCount.get(i).getText();
			System.out.println(sValue);
		}

		Thread.sleep(1000);
		driver.close();
	}
}