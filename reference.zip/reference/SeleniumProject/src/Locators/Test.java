package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Driver/chromedriver.exe");
	
		ChromeDriver driver = new ChromeDriver();
	
		driver.get("https://demo.opencart.com/index.php?route=product/product&path=25_28&product_id=42");
		
		
		WebElement spec = driver.findElement(By.partialLinkText("Specification"));
		spec.click();
		Thread.sleep(2000);
		driver.close();
    }
   }
