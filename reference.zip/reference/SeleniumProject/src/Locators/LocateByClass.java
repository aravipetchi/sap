package Locators;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LocateByClass {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
		WebElement table = driver.findElement(By.className("cinfoT"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		for (WebElement row : rows) {
			List<WebElement> cols = row.findElements(By.tagName("td"));
			for (WebElement col : cols) {
				System.out.print(col.getText() + "\t");
			}
			System.out.println(" ");
		}

		// change drop down values
		WebElement dd = driver.findElement(By.id("cactivity"));
		Select sel = new Select(dd);
		System.out.println("Default value is moderate :" + sel.getFirstSelectedOption().getText());
		sel.selectByIndex(2);
		Thread.sleep(1500);
		System.out.println("changes the value to Light exercise :" + sel.getFirstSelectedOption().getText());
		sel.selectByValue("1.725");
		Thread.sleep(1500);
		System.out.println("Changed the value to very active :" + sel.getFirstSelectedOption().getText());
		sel.selectByVisibleText("Extra Active: very intense exercise daily, or physical job");
		Thread.sleep(1500);
		System.out.println("Changed the value to Extra active : " + sel.getFirstSelectedOption().getText());

		WebElement ageTextbox = driver.findElement(By.id("cage"));
		ageTextbox.clear();
		ageTextbox.sendKeys("45");
		Thread.sleep(1500);
		System.out.println("value of Textbox : " + ageTextbox.getAttribute("value"));

		// identify element by link text ---->text should be static
		driver.findElement(By.linkText("BMI")).click();
		Thread.sleep(1500);
		driver.findElement(By.partialLinkText("Watcher")).click();
		driver.navigate().back();
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().back();
		System.out.println("value of Textbox : " + ageTextbox.getAttribute("value"));
		driver.navigate().refresh();
		System.out.println("value of Textbox : " + ageTextbox.getAttribute("value"));
		driver.close();
	}

}
