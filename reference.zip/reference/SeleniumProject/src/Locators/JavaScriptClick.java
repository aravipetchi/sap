package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptClick {
	

	public static void main(String args[]) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	driver.get("https://www.calculator.net/calorie-calculator.html");
	
	JavascriptExecutor js = (JavascriptExecutor)driver;
	js.executeScript("alert('hello world');");
	Thread.sleep(1500);
	
	

	
	
    WebElement metric = driver.findElement(By.xpath("//*[@id=\"content\"]/h1"));
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String text = executor.executeScript("return arguments[0].text;",metric).toString();
	System.out.println(" "+text);
	//executor.executeScript("arguments[0].click();", metric );
	
	
	
	}
}
