package Locators;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchChrome {

	public static void main(String args[]) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
		//Thread.sleep(1000);

		WebElement ageTextbox = driver.findElement(By.id("cage"));
		ageTextbox.clear();
		ageTextbox.sendKeys("45");
		System.out.println("value of id for ageTextbox : " + ageTextbox.getAttribute("id"));
		System.out.println("value of name for ageTextbox : " + ageTextbox.getAttribute("name"));
		System.out.println("value of type for ageTextbox : " + ageTextbox.getAttribute("type"));
		System.out.println("value of Textbox : " + ageTextbox.getAttribute("value"));
		System.out.println("value of age Textbox : " + ageTextbox.getTagName());
		Thread.sleep(1000);
		
		List<WebElement> genderList = driver.findElements(By.name("csex"));
		for (WebElement gender : genderList) {
			if (gender.getAttribute("value").equals("f")) {
				if (!gender.isSelected()) {
					gender.click();
					break;
				}
			}
		}
		Thread.sleep(1000);
		

		WebElement heightTextbox = driver.findElement(By.id("cheightfeet"));
		heightTextbox.clear();
		heightTextbox.sendKeys("45");
		Thread.sleep(1000);

		

		WebElement weightTextbox = driver.findElement(By.id("cpound"));
		weightTextbox.clear();
		weightTextbox.sendKeys("45");
		Thread.sleep(1000);
		driver.close();
	}

}
