package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByXpath {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
		
		//identifying age label by absolute x_path
		
		WebElement ageLabel = driver.findElement(By.xpath("//*[@id='cpound']"));
		ageLabel.clear();
		ageLabel.sendKeys("45");
		Thread.sleep(1500);
		driver.close();
	}

}
 