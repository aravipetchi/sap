package Lab15;


import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import au.com.bytecode.opencsv.CSVReader;

public class Learning_15 {
	
	 String CSV_PATH="C:\\java_workspace\\SeleniumProject\\src\\Lab15\\UserDetails.csv";
	 WebDriver driver;
	 
	@BeforeTest
	public void setup()  throws Exception {
	
	System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	driver.get("https://demo.opencart.com/");
	driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]")).click();
	driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[1]/a")).click();
	}

	
	@Test	
	public void ReadFromCSV()throws IOException{
		CSVReader reader = new CSVReader(new FileReader(CSV_PATH));
		  String [] csvCell;
		  //while loop will be executed till the last line In CSV.
		  while ((csvCell = reader.readNext()) != null) {   
		   String FName = csvCell[0];
		   String LName = csvCell[1];
		   String Email = csvCell[2];
		   String Mob = csvCell[3];
		   String pass = csvCell[4];
		   String confirmpass = csvCell[5];
		   System.out.println("Fname = " + FName);
		   System.out.println("LName = " + LName);
		   System.out.println("Email = " + Email);
		   System.out.println("Mob = " + Mob);
		   System.out.println("pass = " + pass);
		   System.out.println("confirmpass = " + confirmpass);
		   
	       driver.findElement(By.xpath("//*[@id=\"input-firstname\"]")).sendKeys(FName);
		   driver.findElement(By.xpath("//*[@id=\"input-lastname\"]")).sendKeys(LName);
		   driver.findElement(By.xpath("//*[@id=\"input-email\"]")).sendKeys(Email);
		   driver.findElement(By.xpath("//*[@id=\"input-telephone\"]")).sendKeys(Mob);
		   driver.findElement(By.xpath("//*[@id=\"input-password\"]")).sendKeys(pass);
		   driver.findElement(By.xpath("//*[@id=\"input-confirm\"]")).sendKeys(confirmpass);
		   driver.findElement(By.xpath("//*[@id=\"content\"]/form/fieldset[3]/div/div/label[1]/input")).click();
		   driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[1]")).click();
		   driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[2]")).click();
		   driver.close();
		 }
	}
}