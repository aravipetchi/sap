package Lab13;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;


public class Learning_13 {
	WebDriver driver;
	
	@Test
	public void ReadXML() throws FileNotFoundException, DocumentException {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		
		String filename = System.getProperty("user.dir") + "/src/Lab13/ObjectRepository.xml";
		FileInputStream in = new FileInputStream(new File(filename));
		SAXReader reader = new SAXReader();
		Document document = reader.read(in);
		String Desktop = document.selectSingleNode("//YourStore/Desktop").getText();
		String mac = document.selectSingleNode("//YourStore/mac").getText();
		String macXpath = document.selectSingleNode("//YourStore/macXpath").getText();
		String sortDDId = document.selectSingleNode("//YourStore/sortDDId").getText();
		String addToCartXpath = document.selectSingleNode("//YourStore/addToCartXpath").getText();
		String searchTextBoxName = document.selectSingleNode("//YourStore/searchTextBoxName").getText();
		String searchImageXpath = document.selectSingleNode("//YourStore/searchImageXpath").getText();
		String searchCriteriaId = document.selectSingleNode("//YourStore/searchCriteriaId").getText();
		String chkDescriptionId = document.selectSingleNode("//YourStore/chkDescriptionId").getText();
		String searchBtnId = document.selectSingleNode("//YourStore/searchBtnId").getText();
				
		//System.setProperty("webdriver.chrome.driver",chromedriver);
		//ChromeDriver driver= new ChromeDriver();
		//driver.get(url);
		String actualtitle= driver.getTitle();
		String expectedtitle="Your Store";
		assertEquals(actualtitle, expectedtitle);
		driver.findElement(By.linkText(Desktop)).click();
		driver.findElement(By.linkText(mac)).click();
		String actualhead = driver.findElement(By.xpath(macXpath)).getText();
		String expectedhead= "Mac";
		assertEquals(actualhead, expectedhead);
		WebElement dropdown = driver.findElement(By.id(sortDDId));
		Select se= new Select(dropdown);
		se.selectByVisibleText("Name (A - Z)");
		driver.findElement(By.xpath(addToCartXpath)).click();
		driver.findElement(By.name(searchTextBoxName)).sendKeys("Monitors");
		driver.findElement(By.xpath(searchImageXpath)).click();
		driver.findElement(By.id(searchCriteriaId)).clear();
		driver.findElement(By.id(chkDescriptionId)).click();
		driver.findElement(By.id(searchBtnId)).click();
	}
	
}
