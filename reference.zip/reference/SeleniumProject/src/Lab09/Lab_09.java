package Lab09;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;


public class Lab_09 {


	public static void main(String[] args) throws InterruptedException {
		
		google();
		ie();
		
	}

	public static void google() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		// System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Driver/chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.get("https://demo.opencart.com/index.php?route=common/home");

		driver.findElement(By.partialLinkText("Desktop")).click();
		Thread.sleep(2000);

		driver.findElement(By.partialLinkText("Mac")).click();
		Thread.sleep(2000);
		
		String Title = driver.getTitle();
		System.out.println("The Title is : " + Title);

		if (Title.equals("Mac")) {
			System.out.println("Passed");
		} else {
			System.out.println("Fail");
		}

		WebElement dd= driver.findElement(By.id("input-sort"));
		Select sel = new Select(dd);
		sel.selectByIndex(1);
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\'search\']/input")).click();
		driver.findElement(By.xpath("//*[@id=\'search\']/input")).sendKeys("Mobile");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\'search\']/span/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"input-search\"]")).clear();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"content\"]/p[1]/label")).click();
		driver.findElement(By.id("button-search")).click();

		Thread.sleep(2000);
		driver.close();

	}
	
	
	public static void ie() throws InterruptedException {
		System.setProperty("webdriver.ie.driver", "./Driver/IEDriverServer.exe");
		
		InternetExplorerDriver driver = new InternetExplorerDriver();
		
		driver.get("https://demo.opencart.com/index.php?route=common/home");
		driver.manage().window().maximize();

		driver.findElement(By.partialLinkText("Desktop")).click();
		Thread.sleep(2000);

		driver.findElement(By.partialLinkText("Mac")).click();
		Thread.sleep(2000);
		
		String Title = driver.getTitle();
		System.out.println("The Title is : " + Title);

		if (Title.equals("Mac")) {
			System.out.println("Passed");
		} else {
			System.out.println("Fail");
		}

		WebElement dd= driver.findElement(By.id("input-sort"));
		Select sel = new Select(dd);
		sel.selectByIndex(1);
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\'search\']/input")).click();
		driver.findElement(By.xpath("//*[@id=\'search\']/input")).sendKeys("Mobile");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\'search\']/span/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"input-search\"]")).clear();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"content\"]/p[1]/label")).click();
		driver.findElement(By.id("button-search")).click();

		Thread.sleep(2000);
		driver.close();

	}
	
	
}


