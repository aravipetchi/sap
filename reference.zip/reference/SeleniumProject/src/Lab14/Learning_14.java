package Lab14;


import static org.testng.Assert.assertEquals;
import java.io.IOException;
import java.util.Hashtable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



public class Learning_14 {

	WebDriver driver;
	
	@BeforeClass
	public void before() {
		
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://demo.opencart.com");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();
	}
	
	@Test(dataProvider="AcceptUserDetails")
	public void YourStore(Hashtable<String, String> tb) throws InterruptedException{
		
		//driver.findElement(By.linkText("My Account")).click();
		//driver.findElement(By.linkText("Register")).click();
		WebElement firstTxt=driver.findElement(By.name("firstname"));
		firstTxt.clear();
		firstTxt.sendKeys(tb.get("FirstName"));
		WebElement lastTxtdriver= driver.findElement(By.name("lastname"));
		lastTxtdriver.clear();
		lastTxtdriver.sendKeys(tb.get("LastName"));
		WebElement email = driver.findElement(By.id("input-email"));
		email.clear();		
		email.sendKeys(tb.get("Email"));
		WebElement tel = driver.findElement(By.id("input-telephone"));
		tel.clear();		
		tel.sendKeys(tb.get("Telephone"));
		WebElement pass = driver.findElement(By.id("input-password"));
		pass.clear();
		pass.sendKeys(tb.get("Password"));
		WebElement confirmpass = driver.findElement(By.id("input-confirm"));
		confirmpass.clear();
		confirmpass.sendKeys(tb.get("ConfirmPass"));
		WebElement chkbox = driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[1]"));
		chkbox.click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Logout")).click();
		
		String expected = "Your Account Has Been Created!" ;
		String actual = driver.findElement(By.xpath("//*[@id=\"content\"]/h1")).getText();
		assertEquals(actual, expected);
		
	}
	@DataProvider
	public Object[][] AcceptUserDetails() throws IOException {
		
		String filename ="UserDetails.xlsx";
		String filepath= System.getProperty("user.dir")+"/src/lab14";
		String sheetname = "user1";
		return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);
	}
}

