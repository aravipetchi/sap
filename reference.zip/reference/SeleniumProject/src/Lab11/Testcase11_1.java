package Lab11;



import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class Testcase11_1 {
	WebDriver driver;
	Pageobject_11_1 page;	
	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		page = new Pageobject_11_1(driver);
	}

	@Test
	public void Testcases() {
		page.VerifyTitle();
	
	}
	
	@Test
	public void testCase() {
		page.SeDeskButton();
		page.SelMac();
		page.VerifyMacHead();
		page.sortandSelect("Name (A - Z)");
		page.addingtoCart();
		page.SelectSearchAndSend("Mobile");
		page.selectSearc1();
		page.SelDescAndSelectsearch();
		page.SelectsearcandsendKeys("Monitors");
	}
	

}
