package Lab11;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class PageFactory11_2 {
	WebDriver driver;
	@FindBy(xpath="//*[@id=\"menu\"]/div[2]/ul/li[1]") 
	WebElement desktopButton;
	
	@FindBy(xpath="//*[@id=\"menu\"]/div[2]/ul/li[1]/div/div/ul/li[2]/a")
	WebElement Mac1;
	
	@FindBy(xpath="//*[@id=\"content\"]/h2")
	WebElement Mac1Heading;
	
	@FindBy(id="input-sort")
	WebElement sortBy;
	
	@FindBy(xpath="//*[@id=\"content\"]/div[2]/div/div/div[2]/div[2]/button[1]")
	WebElement addcart;
	
	@FindBy(name="search")
	WebElement searchLoc;
	
	@FindBy(className="input-group-btn")
	WebElement search;
	
	@FindBy(xpath="//*[@id=\"input-search\"]")
	WebElement search1;
	
	@FindBy(name="description") 
	WebElement selectDesc;
	
	@FindBy(id="button-search")
	WebElement SearchN;
	
	@FindBy(id="input-search")
	WebElement Selsearch;
	
	@FindBy(id="button-search") WebElement Clicksearch;
	
	public PageFactory11_2(WebDriver driver1) {
		this.driver=driver1;
	}
	public void VerifyTitle() {

		String title=driver.getTitle();
		String Title = "Your Store";
		if (title.equals(Title)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
	}
	public void SeDeskButton() {
		desktopButton.click();
	}
	public void SelMac() {
		Mac1.click();
		
	}
	public void VerifyMacHead() {
		 String Title = "Mac";
		if (Mac1Heading.getText().equals(Title)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
	}
	public void sortandSelect(String drop) {
		//driver.findElement(sortBy).click();
		Select sel = new Select(sortBy);
		 sel.selectByVisibleText(drop);
		//driver.findElement(selectby).click();
	}
	public void addingtoCart() {
		addcart.click();
	}
	public void SelectSearchAndSend(String name) {
		searchLoc.sendKeys(name);
		search.click();
		}
	public void selectSearc1() {
		search1.clear();
	}
	public void SelDescAndSelectsearch() {
		selectDesc.click();
		SearchN.click();
	}
	public void SelectsearcandsendKeys(String name2) {
		Selsearch.clear();
		Selsearch.sendKeys(name2);
		Clicksearch.click();
	}
	
	

}

	