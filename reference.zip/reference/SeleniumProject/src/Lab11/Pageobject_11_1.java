package Lab11;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
       
public class Pageobject_11_1 {
	WebDriver driver;
	By desktopButton=By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[1]");
	By Mac1=By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[1]/div/div/ul/li[2]/a");
	By Mac1Heading=By.xpath("//*[@id=\"content\"]/h2");
	By sortBy=By.id("input-sort");
	//By dd=By.id("Name (A - Z)");
	//By selectby=.selectByVisibleText("Name (A - Z)");
	By addcart=By.xpath("//*[@id=\"content\"]/div[2]/div/div/div[2]/div[2]/button[1]");
	By searchLoc=By.name("search");
	By search=By.className("input-group-btn");
    By search1=By.xpath("//*[@id=\"input-search\"]");
	By selectDesc=By.name("description");
	By SearchN=By.id("button-search");
	By Selsearch=By.id("input-search");
	By Clicksearch=By.id("button-search");

	public Pageobject_11_1(WebDriver driver1) {
		this.driver=driver1;
		
	}
	
	
	public void VerifyTitle() {
		String title=driver.getTitle();
		String Title = "Your Store";
		if (title.equals(Title)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
	}
	public void SeDeskButton() {
		driver.findElement(desktopButton).click();
	}
	public void SelMac() {
		driver.findElement(Mac1).click();
		
	}
	public void VerifyMacHead() {
		 String Title = "Mac";
		if (driver.findElement(Mac1Heading).getText().equals(Title)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
	}
	public void sortandSelect(String drop) {
		//driver.findElement(sortBy).click();
		Select sel = new Select(driver.findElement(sortBy));
		 sel.selectByVisibleText(drop);
		//driver.findElement(selectby).click();
	}
	public void addingtoCart() {
		driver.findElement(addcart).click();
	}
	public void SelectSearchAndSend(String name) {
		driver.findElement(searchLoc).sendKeys(name);
		driver.findElement(search).click();
		}
	public void selectSearc1() {
		driver.findElement(search1).clear();
	}
	public void SelDescAndSelectsearch() {
		driver.findElement(selectDesc).click();
		driver.findElement(SearchN).click();
	}
	public void SelectsearcandsendKeys(String name2) {
		driver.findElement(Selsearch).clear();
		driver.findElement(Selsearch).sendKeys(name2);
		driver.findElement(Clicksearch).click();
	}
	
	}
