package Lab11;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



public class Testcase11_2 {
	WebDriver driver;
	PageFactory11_2 page;
	@BeforeClass
	public   void Testcases() {
		 System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Driver/chromedriver.exe");
		 driver =new ChromeDriver();
			driver.get("http://demo.opencart.com/");
			  page=new PageFactory11_2(driver);
			  page=PageFactory.initElements(driver,PageFactory11_2.class);
			}
	@Test
	public void TestCase1() {
			page.VerifyTitle();
			
	}
	@Test
	public void TestCase2() {
		 
		    page.SeDeskButton();
		    page.SelMac();
			page.VerifyMacHead();
			page.sortandSelect("Name (A - Z)");
			page.addingtoCart();
			page.SelectSearchAndSend("Mobile");
			page.selectSearc1();
			page.SelDescAndSelectsearch();
			page.SelectsearcandsendKeys("Monitors");
			
			
}
}
