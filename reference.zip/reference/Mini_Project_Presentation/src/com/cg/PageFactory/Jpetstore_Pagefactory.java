package com.cg.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author maheswaran
 *
 */
public class Jpetstore_Pagefactory {
	WebDriver driver;
	
	
	@FindBy(xpath = "//*[@id=\"MenuContent\"]/a[2]]")
	@CacheLookup
	public WebElement signin;

	@FindBy(name = "username")
	@CacheLookup
	public WebElement username;

	@FindBy(name = "password")
	@CacheLookup
	public WebElement password;

	@FindBy(id = "login")
	@CacheLookup
	public WebElement login;

	@FindBy(xpath = "//*[@id=\"Catalog\"]/a")
	@CacheLookup
	public WebElement Register;

	@FindBy(xpath = "//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[1]/a")
	@CacheLookup
	public WebElement product;

	@FindBy(xpath = "//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[5]/a")
	@CacheLookup
	public WebElement addtocart;

	@FindBy(xpath = "//*[@id=\"MainImageContent\"]/map/area[3]")
	@CacheLookup
	public WebElement doglink;

	@FindBy(xpath = "//*[@id=\"MenuContent\"]/a[2]")
	@CacheLookup
	public WebElement signout;

	public Jpetstore_Pagefactory(WebDriver driver1) {

		this.driver = driver1;
		PageFactory.initElements(driver1, this);
	}
}
